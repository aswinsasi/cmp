/**
 * CMP LAN Transport
 * Uses UDP multicast for beacon discovery and TCP for reliable data transfer.
 * Supports both same-machine (multiple terminals) and cross-machine discovery.
 *
 * Discovery: UDP multicast on 239.77.67.80:43580
 * Data: TCP server on a random high port (advertised in beacon header)
 *
 * UDP packet format:
 *   [instanceId: 8 bytes][tcpPort: 2 bytes BE][beacon payload: N bytes]
 *
 * We filter our own beacons by instanceId (NOT by IP address), so
 * multiple nodes on the same machine can discover each other.
 *
 * @module transport/lan-transport
 * @author Agent Viscro
 */

import dgram from 'dgram';
import net from 'net';
import { ITransport, TransportEvent, TransportEventHandler } from './interface';

const CMP_MULTICAST_ADDR = '239.77.67.80';
const CMP_UDP_PORT = 43580;
const MAX_TCP_MESSAGE = 1048576;
const FRAME_HEADER_SIZE = 4;
const UDP_HEADER_SIZE = 10; // 8 instanceId + 2 tcpPort

export class LANTransport implements ITransport {
  readonly name = 'lan';
  readonly maxPayloadBytes = MAX_TCP_MESSAGE;
  readonly estimatedBandwidthMbps = 1000;

  private running = false;
  private udpSocket: dgram.Socket | null = null;
  private tcpServer: net.Server | null = null;
  private tcpPort = 0;
  private beaconTimer: ReturnType<typeof setInterval> | null = null;
  private beaconData: Uint8Array | null = null;

  /** Random 8-byte ID to filter our own multicast beacons */
  private instanceId: Uint8Array;

  /** peer address "ip:port" → TCP socket */
  private peerConnections = new Map<string, net.Socket>();
  /** peer address → receive buffer */
  private receiveBuffers = new Map<string, Buffer>();
  /** peer IP → their advertised TCP port */
  private peerTcpPorts = new Map<string, number>();
  /** Event handlers */
  private handlers = new Map<string, Set<TransportEventHandler>>();

  constructor() {
    this.instanceId = new Uint8Array(8);
    for (let i = 0; i < 8; i++) {
      this.instanceId[i] = Math.floor(Math.random() * 256);
    }
    // Ensure first byte is never 0xFE (reserved for UDP protocol messages)
    if (this.instanceId[0] === 0xFE) this.instanceId[0] = 0x00;
  }

  // ── Lifecycle ──

  async start(): Promise<void> {
    if (this.running) return;
    await this.startTCP();
    await this.startUDP();
    this.running = true;
  }

  async stop(): Promise<void> {
    this.running = false;
    await this.stopBeaconing();

    for (const [, socket] of this.peerConnections) socket.destroy();
    this.peerConnections.clear();
    this.receiveBuffers.clear();
    this.peerTcpPorts.clear();

    if (this.udpSocket) {
      try { this.udpSocket.dropMembership(CMP_MULTICAST_ADDR); } catch {}
      this.udpSocket.close();
      this.udpSocket = null;
    }
    if (this.tcpServer) {
      this.tcpServer.close();
      this.tcpServer = null;
    }
  }

  isRunning(): boolean {
    return this.running;
  }

  // ── Discovery ──

  async startBeaconing(beaconData: Uint8Array, intervalMs: number): Promise<void> {
    this.beaconData = beaconData;
    this.sendBeacon();
    this.beaconTimer = setInterval(() => this.sendBeacon(), intervalMs);
  }

  async stopBeaconing(): Promise<void> {
    if (this.beaconTimer) {
      clearInterval(this.beaconTimer);
      this.beaconTimer = null;
    }
    this.beaconData = null;
  }

  async startScanning(): Promise<void> { /* always active once UDP starts */ }
  async stopScanning(): Promise<void> { /* no-op */ }

  // ── Data Transfer ──

  async sendTo(peerAddress: string, data: Uint8Array): Promise<void> {
    if (!this.running) throw new Error('Transport not running');
    if (data.length > MAX_TCP_MESSAGE) throw new Error(`Payload too large: ${data.length}`);

    const [host] = peerAddress.split(':');

    // Strategy: TCP first (reliable), UDP as parallel backup for small messages.
    // This fixes same-machine scenarios where UDP unicast to a shared port
    // only reaches one of two processes bound to that port.

    // 1. Try TCP (existing connection or establish new one)
    let tcpSent = false;
    try {
      let socket = this.peerConnections.get(peerAddress);
      if (socket && (socket.destroyed || !socket.writable || socket.readableEnded)) {
        this.peerConnections.delete(peerAddress);
        socket = undefined;
      }
      if (!socket) {
        socket = await this.connectToPeer(peerAddress);
      }

      const frame = Buffer.alloc(FRAME_HEADER_SIZE + data.length);
      frame.writeUInt32BE(data.length, 0);
      frame.set(data, FRAME_HEADER_SIZE);

      await new Promise<void>((resolve, reject) => {
        socket!.write(frame, (err) => { if (err) reject(err); else resolve(); });
      });
      tcpSent = true;
    } catch {
      // TCP failed — will fall back to UDP below
    }

    // 2. For small messages, also send via UDP as backup (helps when TCP isn't established yet)
    // On different machines this provides faster first delivery; on same machine TCP handles it
    if (!tcpSent && data.length < 60000 && this.udpSocket && host) {
      const headerSize = 1 + 8 + 2; // prefix + instanceId + tcpPort
      const prefixed = Buffer.alloc(headerSize + data.length);
      prefixed[0] = LANTransport.UDP_MSG_PREFIX;
      prefixed.set(this.instanceId, 1);
      prefixed.writeUInt16BE(this.tcpPort, 9);
      prefixed.set(data, headerSize);
      this.udpSocket.send(prefixed, 0, prefixed.length, CMP_UDP_PORT, host, () => {});
    }
  }

  async broadcast(data: Uint8Array): Promise<void> {
    if (!this.running) throw new Error('Transport not running');

    // Try TCP to all connected peers
    const promises: Promise<void>[] = [];
    for (const [addr] of this.peerConnections) {
      promises.push(this.sendTo(addr, data).catch(() => { this.peerConnections.delete(addr); }));
    }
    await Promise.allSettled(promises);

    // Also broadcast via UDP for peers where TCP is blocked
    // Same format as sendTo: [0xFE][instanceId: 8B][tcpPort: 2B BE][payload]
    if (this.udpSocket && data.length < 60000) {
      const headerSize = 1 + 8 + 2;
      const prefixed = Buffer.alloc(headerSize + data.length);
      prefixed[0] = LANTransport.UDP_MSG_PREFIX;
      prefixed.set(this.instanceId, 1);
      prefixed.writeUInt16BE(this.tcpPort, 9);
      prefixed.set(data, headerSize);
      try {
        this.udpSocket.send(prefixed, 0, prefixed.length, CMP_UDP_PORT, '255.255.255.255');
      } catch {}
    }
  }

  // ── Events ──

  on(event: string, handler: TransportEventHandler): void {
    if (!this.handlers.has(event)) this.handlers.set(event, new Set());
    this.handlers.get(event)!.add(handler);
  }

  off(event: string, handler: TransportEventHandler): void {
    const set = this.handlers.get(event);
    if (set) { set.delete(handler); if (set.size === 0) this.handlers.delete(event); }
  }

  private emit(event: TransportEvent): void {
    for (const key of [event.type, 'all']) {
      const set = this.handlers.get(key);
      if (set) { for (const h of set) { try { h(event); } catch {} } }
    }
  }

  // ── TCP (port 0 = OS assigns free port, no conflicts) ──

  private async startTCP(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.tcpServer = net.createServer((socket) => this.handleIncomingTCP(socket));
      this.tcpServer.on('error', reject);
      this.tcpServer.listen(0, () => {
        const addr = this.tcpServer!.address() as net.AddressInfo;
        this.tcpPort = addr.port;
        resolve();
      });
    });
  }

  // ── UDP (multicast loopback ENABLED for same-machine discovery) ──

  private async startUDP(): Promise<void> {
    return new Promise((resolve) => {
      this.udpSocket = dgram.createSocket({ type: 'udp4', reuseAddr: true });

      this.udpSocket.on('error', (err) => {
        this.emit({ type: 'error', data: new TextEncoder().encode(err.message), transport: this.name, timestamp: Date.now() });
      });

      this.udpSocket.on('message', (msg, rinfo) => this.handleUDP(msg, rinfo));

      this.udpSocket.bind(CMP_UDP_PORT, () => {
        try {
          // Enable broadcast (works on hotspots where multicast doesn't)
          this.udpSocket!.setBroadcast(true);
          // Also try multicast (works on routers/LAN)
          this.udpSocket!.addMembership(CMP_MULTICAST_ADDR);
          this.udpSocket!.setMulticastTTL(4);
          this.udpSocket!.setMulticastLoopback(true);
        } catch {}
        resolve();
      });
    });
  }

  // ── UDP Beacon Handling ──

  /** Prefix byte for protocol messages sent via UDP fallback */
  private static readonly UDP_MSG_PREFIX = 0xFE;

  private handleUDP(msg: Buffer, rinfo: dgram.RemoteInfo): void {
    if (msg.length < 2) return;

    // Check if this is a protocol message (UDP fallback) or a beacon
    if (msg[0] === LANTransport.UDP_MSG_PREFIX) {
      // Protocol message format: [0xFE][instanceId: 8B][tcpPort: 2B BE][payload]
      if (msg.length < 11) return; // 1 + 8 + 2 minimum

      // Filter own messages by instanceId (same mechanism as beacons)
      const senderId = msg.slice(1, 9);
      let isOwn = true;
      for (let i = 0; i < 8; i++) {
        if (senderId[i] !== this.instanceId[i]) { isOwn = false; break; }
      }
      if (isOwn) return;

      // Extract sender's TCP port and payload
      const senderTcpPort = msg.readUInt16BE(9);
      const payload = msg.slice(11);
      const peerAddress = `${rinfo.address}:${senderTcpPort}`;

      // Update known TCP port for this peer
      // Key by ip:tcpPort to support multiple nodes on same machine
      this.peerTcpPorts.set(rinfo.address + ':' + senderTcpPort, senderTcpPort);

      this.emit({
        type: 'message',
        peerAddress,
        data: new Uint8Array(payload),
        transport: this.name,
        timestamp: Date.now(),
      });
      return;
    }

    // Otherwise treat as beacon
    if (msg.length < UDP_HEADER_SIZE) return;

    const senderId = msg.slice(0, 8);
    let isOwn = true;
    for (let i = 0; i < 8; i++) {
      if (senderId[i] !== this.instanceId[i]) { isOwn = false; break; }
    }
    if (isOwn) return;

    const senderTcpPort = msg.readUInt16BE(8);
    const beaconPayload = new Uint8Array(msg.slice(UDP_HEADER_SIZE));
    const peerAddress = `${rinfo.address}:${senderTcpPort}`;

    this.peerTcpPorts.set(rinfo.address, senderTcpPort);

    this.emit({
      type: 'peer_discovered',
      peerAddress,
      data: beaconPayload,
      transport: this.name,
      timestamp: Date.now(),
    });
  }

  private sendBeacon(): void {
    if (!this.udpSocket || !this.beaconData) return;

    const packet = Buffer.alloc(UDP_HEADER_SIZE + this.beaconData.length);
    packet.set(this.instanceId, 0);
    packet.writeUInt16BE(this.tcpPort, 8);
    packet.set(this.beaconData, UDP_HEADER_SIZE);

    // Send via multicast (works on routers/LAN)
    try {
      this.udpSocket.send(packet, 0, packet.length, CMP_UDP_PORT, CMP_MULTICAST_ADDR);
    } catch {}

    // Also send via broadcast (works on mobile hotspots where multicast is blocked)
    try {
      this.udpSocket.send(packet, 0, packet.length, CMP_UDP_PORT, '255.255.255.255');
    } catch {}
  }

  // ── TCP Connections ──

  private async connectToPeer(peerAddress: string): Promise<net.Socket> {
    const [host, portStr] = peerAddress.split(':');
    const port = parseInt(portStr, 10);
    if (!host || !port) throw new Error(`Invalid peer address: ${peerAddress}`);

    return new Promise((resolve, reject) => {
      const socket = net.createConnection({ host, port, timeout: 5000 }, () => {
        // Keep connection alive
        socket.setKeepAlive(true, 5000);
        socket.setNoDelay(true);

        this.peerConnections.set(peerAddress, socket);
        this.receiveBuffers.set(peerAddress, Buffer.alloc(0));

        socket.on('data', (chunk: Buffer) => this.handleTCPData(peerAddress, chunk));
        socket.on('close', () => { this.cleanupPeer(peerAddress); });
        socket.on('error', () => { this.cleanupPeer(peerAddress); });

        resolve(socket);
      });
      socket.on('error', (err) => reject(new Error(`Connect to ${peerAddress}: ${err.message}`)));
      socket.on('timeout', () => { socket.destroy(); reject(new Error(`Timeout: ${peerAddress}`)); });
    });
  }

  private handleIncomingTCP(socket: net.Socket): void {
    // Keep connection alive
    socket.setKeepAlive(true, 5000);
    socket.setNoDelay(true);

    const remoteIp = socket.remoteAddress?.replace('::ffff:', '') || 'unknown';
    const knownPort = this.peerTcpPorts.get(remoteIp);
    const addr = knownPort ? `${remoteIp}:${knownPort}` : `${remoteIp}:${socket.remotePort}`;

    this.peerConnections.set(addr, socket);
    this.receiveBuffers.set(addr, Buffer.alloc(0));

    socket.on('data', (chunk: Buffer) => this.handleTCPData(addr, chunk));
    socket.on('close', () => this.cleanupPeer(addr));
    socket.on('error', () => this.cleanupPeer(addr));
  }

  private handleTCPData(addr: string, chunk: Buffer): void {
    let buffer = this.receiveBuffers.get(addr) || Buffer.alloc(0);
    buffer = Buffer.concat([buffer, chunk]);

    while (buffer.length >= FRAME_HEADER_SIZE) {
      const msgLength = buffer.readUInt32BE(0);
      if (msgLength > MAX_TCP_MESSAGE) { buffer = Buffer.alloc(0); break; }
      const totalLength = FRAME_HEADER_SIZE + msgLength;
      if (buffer.length < totalLength) break;

      const payload = buffer.slice(FRAME_HEADER_SIZE, totalLength);
      buffer = buffer.slice(totalLength);

      this.emit({ type: 'message', peerAddress: addr, data: new Uint8Array(payload), transport: this.name, timestamp: Date.now() });
    }

    this.receiveBuffers.set(addr, buffer);
  }

  private cleanupPeer(addr: string): void {
    this.peerConnections.delete(addr);
    this.receiveBuffers.delete(addr);
    this.emit({ type: 'peer_lost', peerAddress: addr, transport: this.name, timestamp: Date.now() });
  }

  getTcpPort(): number { return this.tcpPort; }
  get connectedPeerCount(): number { return this.peerConnections.size; }
  getConnectedPeers(): string[] { return [...this.peerConnections.keys()]; }

  /**
   * Send beacon directly to a specific IP address.
   * Used for manual peer connection when multicast/broadcast is blocked.
   */
  sendBeaconTo(ip: string): void {
    if (!this.udpSocket || !this.beaconData) return;
    const packet = Buffer.alloc(UDP_HEADER_SIZE + this.beaconData.length);
    packet.set(this.instanceId, 0);
    packet.writeUInt16BE(this.tcpPort, 8);
    packet.set(this.beaconData, UDP_HEADER_SIZE);
    try {
      this.udpSocket.send(packet, 0, packet.length, CMP_UDP_PORT, ip);
    } catch {}
  }
}
